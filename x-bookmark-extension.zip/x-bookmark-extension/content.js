/* X 북마크 → 엑셀(CSV) 내보내기 · 콘텐츠 스크립트 (확장프로그램용)
   - 1만개 이상 대응 / 백그라운드 탭 동작
   - 시작 전 수량 지정(체크박스) / 정리 후 북마크 자동 해제 선택
   - 패널 색상을 사용자의 X 테마(배경 모드 + 강조색)에 맞춰 자동 적용 */

(function () {
  'use strict';

  /* ============================================================
     ★★★ 태그 규칙 — 자유롭게 수정하세요 ★★★
     ============================================================ */
  const TAG_RULES = [
    { tag: 'TRPG',       keywords: ['TRPG', 'roll20', '롤20', '코코포리아'] },
    { tag: 'CoC',       keywords: ['크툴루', '크툴루의 부름', 'CoC', '수호자', '탐사자', '키퍼', '러브크래프트'] },
    { tag: 'DnD',       keywords: ['던전앤드래곤', '던전 앤 드래곤', 'DnD', 'D&D', '디앤디'] },
    { tag: '인세인',     keywords: ['인세인', 'insane', '봉마인'] },
    { tag: '시노비가미',  keywords: ['시노비가미', '시노비'] },
    { tag: '더블크로스',  keywords: ['더블크로스', '덥크', 'DX3rd'] },
    { tag: '마기카로기아', keywords: ['마기카로기아', '마기로기'] },
    { tag: '아곤', keywords: ['아곤', 'agon'] },
    { tag: '언성듀엣', keywords: ['언성듀엣', '언듀', 'unsung duet'] },
    { tag: '스트라토샤우트', keywords: ['스트라토샤우트', '스샤', '스샤토'] },
    { tag: '시나리오', keywords: ['시나리오', '번역'] },
    { tag: '디자인',   keywords: ['일러스트', '디자인', '도트', '로고', '폰트', '배경', '캐릭터시트', '캐릭터 시트', '맵시트', '맵 시트', '커스텀시트', '커스텀 시트', '컷인', '세션카드', '캐릭터 폼', '디자인 폼', '나나곰 폼', '핸드아웃', '인트로', '롤꾸', '토큰', '광기카드', '매크로'] },
    { tag: '음악',  keywords: ['BGM', '음악', '효과음', '브금'] },
    { tag: '확장프로그램/티스토리 스킨', keywords: ['확장프로그램', '확장 프로그램', '티스토리', '스킨', '갠홈', '코드', 'api'] },
    { tag: '커미션', keywords: ['커미션'] },
  ];
  const MEDIA_ONLY_TEXT_LIMIT = 15;
  const MAX_SCROLLS = 8000; // 1만개 이상 대응 (더 이상 안 늘면 자동 종료)
  /* ============================================================ */

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------- X 테마 색상 감지 ---------- */
  function parseRGB(s) {
    const m = (s || '').match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const p = m[1].split(',').map((x) => parseFloat(x));
    return { r: p[0], g: p[1], b: p[2], a: p[3] === undefined ? 1 : p[3] };
  }
  function isDark(s) {
    const c = parseRGB(s);
    if (!c) return false;
    return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255 < 0.5;
  }
  function getTheme() {
    let accent = 'rgb(29, 155, 240)'; // 기본 X 블루
    const accentBtn =
      document.querySelector('[data-testid="SideNav_NewTweet_Button"]') ||
      document.querySelector('[data-testid="tweetButtonInline"]') ||
      document.querySelector('[data-testid="tweetButton"]');
    if (accentBtn) {
      let c = getComputedStyle(accentBtn).backgroundColor;
      let pc = parseRGB(c);
      if (!pc || pc.a === 0) {
        const child = accentBtn.querySelector('div, span');
        if (child) { c = getComputedStyle(child).backgroundColor; pc = parseRGB(c); }
      }
      if (pc && pc.a !== 0) accent = c;
    }
    const cs = getComputedStyle(document.body);
    let bg = cs.backgroundColor;
    if (!parseRGB(bg) || parseRGB(bg).a === 0) bg = 'rgb(255, 255, 255)';
    const text = cs.color || 'rgb(15, 20, 25)';
    const dark = isDark(bg);
    return {
      accent,
      bg,
      text,
      border: dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.12)',
      subtext: dark ? 'rgba(255,255,255,.6)' : 'rgba(0,0,0,.5)',
      inputBg: dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.03)',
      accentText: isDark(accent) ? '#ffffff' : '#0f1419',
    };
  }

  /* ---------- 백그라운드 유지(무음 오디오) ---------- */
  let _audioCtx = null;
  function startKeepAwake() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      _audioCtx = new AC();
      const osc = _audioCtx.createOscillator();
      const gain = _audioCtx.createGain();
      gain.gain.value = 0.0005;
      osc.frequency.value = 60;
      osc.connect(gain).connect(_audioCtx.destination);
      osc.start();
    } catch (e) { /* 무시 */ }
  }
  function stopKeepAwake() {
    try { if (_audioCtx) { _audioCtx.close(); _audioCtx = null; } } catch (e) { /* 무시 */ }
  }

  /* ---------- 컨트롤 패널 ---------- */
  let statusEl, startBtn, numChk, numInput, removeChk, panel;
  function makePanel() {
    if (document.getElementById('xbm-panel')) return;
    const t = getTheme();
    panel = document.createElement('div');
    panel.id = 'xbm-panel';
    Object.assign(panel.style, {
      position: 'fixed', left: '24px', bottom: '24px', zIndex: 99999,
      width: '240px', padding: '14px 16px', borderRadius: '16px',
      background: t.bg, color: t.text, border: '1px solid ' + t.border,
      boxShadow: '0 6px 24px rgba(0,0,0,.28)',
      fontFamily: 'system-ui, sans-serif', fontSize: '14px', lineHeight: '1.4',
    });
    panel.innerHTML = `
      <div style="font-weight:800;margin-bottom:12px;font-size:15px;">📥 북마크 내보내기</div>
      <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px;cursor:pointer;">
        <input type="checkbox" id="xbm-numchk">
        <span>개수 지정</span>
        <input type="number" id="xbm-count" min="1" placeholder="100" disabled
          style="width:62px;margin-left:auto;padding:4px 6px;border:1px solid ${t.border};border-radius:8px;background:${t.inputBg};color:${t.text};">
        <span style="opacity:.7;">개</span>
      </label>
      <label style="display:flex;align-items:center;gap:8px;margin-bottom:12px;cursor:pointer;">
        <input type="checkbox" id="xbm-removechk">
        <span>정리 후 북마크 해제</span>
      </label>
      <button id="xbm-start"
        style="width:100%;padding:9px;border:none;border-radius:9999px;background:${t.accent};color:${t.accentText};font-weight:700;font-size:14px;cursor:pointer;">
        시작
      </button>
      <div id="xbm-status" style="margin-top:9px;font-size:12.5px;color:${t.subtext};text-align:center;">대기 중</div>
    `;
    document.body.appendChild(panel);

    numChk = panel.querySelector('#xbm-numchk');
    numInput = panel.querySelector('#xbm-count');
    removeChk = panel.querySelector('#xbm-removechk');
    startBtn = panel.querySelector('#xbm-start');
    statusEl = panel.querySelector('#xbm-status');

    // 체크박스 색상도 X 강조색에 맞춤
    [numChk, removeChk, numInput].forEach((el) => (el.style.accentColor = t.accent));

    numChk.addEventListener('change', () => {
      numInput.disabled = !numChk.checked;
      if (numChk.checked) numInput.focus();
    });

    startBtn.addEventListener('click', () => {
      let target = null; // null = 전체
      if (numChk.checked) {
        target = parseInt(numInput.value, 10);
        if (!target || target < 1) { setStatus('⚠️ 개수를 올바르게 입력하세요'); return; }
      }
      const doRemove = removeChk.checked;
      if (doRemove) {
        const msg = target
          ? `최신 북마크 ${target}개를 내보낸 뒤 해당 북마크를 해제합니다.`
          : `전체 북마크를 내보낸 뒤 모두 해제합니다.`;
        if (!window.confirm(`⚠️ 주의\n\n${msg}\n해제된 북마크는 되돌릴 수 없습니다. 계속할까요?`)) return;
      }
      runExport(target, doRemove);
    });
  }
  function setStatus(t) { if (statusEl) statusEl.textContent = t; }
  function lockUI(lock) {
    [startBtn, numChk, removeChk].forEach((el) => { if (el) el.disabled = lock; });
    if (numInput) numInput.disabled = lock || !numChk.checked;
    if (startBtn) {
      startBtn.style.opacity = lock ? '0.6' : '1';
      startBtn.style.cursor = lock ? 'wait' : 'pointer';
    }
  }

  /* ---------- 태그 분류 & 트윗 추출 ---------- */
  function classify(item) {
    const tags = [];
    const text = (item.text || '').toLowerCase();
    const isShort = item.text.replace(/\s/g, '').length <= MEDIA_ONLY_TEXT_LIMIT;
    if (item.hasVideo === 'Y' && isShort) tags.push('동영상');
    else if (item.images && isShort) tags.push('이미지');
    for (const rule of TAG_RULES) {
      if (rule.keywords.some((kw) => text.includes(kw.toLowerCase()))) tags.push(rule.tag);
    }
    if (tags.length === 0) tags.push('미분류');
    return [...new Set(tags)].join(' / ');
  }

  function permalinkOf(article) {
    const timeEl = article.querySelector('time');
    const linkEl = timeEl ? timeEl.closest('a') : null;
    return linkEl ? 'https://x.com' + linkEl.getAttribute('href') : null;
  }

  function extractTweets(collected) {
    document.querySelectorAll('article[data-testid="tweet"]').forEach((article) => {
      try {
        const permalink = permalinkOf(article);
        if (!permalink || collected.has(permalink)) return;
        const timeEl = article.querySelector('time');
        const datetime = timeEl ? timeEl.getAttribute('datetime') : '';

        const userBlock = article.querySelector('[data-testid="User-Name"]');
        let displayName = '', handle = '';
        if (userBlock) {
          displayName = (userBlock.innerText.split('\n').filter(Boolean)[0]) || '';
          const m = userBlock.innerText.match(/@\w+/);
          handle = m ? m[0] : '';
        }
        const textEl = article.querySelector('[data-testid="tweetText"]');
        const text = textEl ? textEl.innerText.replace(/\s*\n\s*/g, ' ').trim() : '';
        const images = [...article.querySelectorAll('[data-testid="tweetPhoto"] img')]
          .map((img) => img.src).filter(Boolean)
          .map((src) => src.replace(/&name=\w+/, '&name=orig')).join(' | ');
        const hasVideo =
          article.querySelector('[data-testid="videoPlayer"]') || article.querySelector('video') ? 'Y' : '';

        collected.set(permalink, { displayName, handle, text, images, hasVideo, datetime, permalink });
      } catch (e) { /* 무시 */ }
    });
  }

  /* ---------- 정리 후 북마크 해제 ---------- */
  async function unbookmark(permalinkSet) {
    window.scrollTo(0, 0);
    await sleep(1500);
    let removed = 0, idle = 0;
    while (permalinkSet.size > 0 && idle < 8) {
      const articles = [...document.querySelectorAll('article[data-testid="tweet"]')];
      let acted = false;
      for (const art of articles) {
        const permalink = permalinkOf(art);
        if (!permalink || !permalinkSet.has(permalink)) continue;
        const btn = art.querySelector('[data-testid="removeBookmark"]');
        if (!btn) continue;
        btn.click();
        permalinkSet.delete(permalink);
        removed++;
        setStatus(`🗑️ 북마크 해제 중... ${removed}개`);
        acted = true;
        await sleep(650);
        break; // DOM이 바뀌므로 다시 조회
      }
      if (!acted) { idle++; window.scrollTo(0, 0); await sleep(1000); }
      else idle = 0;
    }
    return removed;
  }

  /* ---------- 메인 실행 ---------- */
  async function runExport(target, doRemove) {
    lockUI(true);
    startKeepAwake();

    const collected = new Map();
    let lastCount = -1, stable = 0;
    const goal = target ? `/ ${target}` : '';

    for (let i = 0; i < MAX_SCROLLS; i++) {
      extractTweets(collected);
      setStatus(`⏳ 수집 중... ${collected.size}개 ${goal}`);
      if (target && collected.size >= target) break;
      window.scrollBy(0, window.innerHeight * 2);
      await sleep(1300);
      if (collected.size === lastCount) { if (++stable >= 7) break; }
      else { stable = 0; lastCount = collected.size; }
    }
    extractTweets(collected);

    let rows = [...collected.values()];
    if (target) rows = rows.slice(0, target); // 최신순 지정 개수

    if (rows.length === 0) { stopKeepAwake(); setStatus('⚠️ 북마크 없음'); lockUI(false); return; }

    // CSV 생성 & 다운로드
    const headers = ['번호', '태그', '작성자', '계정', '내용', '이미지URL', '동영상', '날짜', '링크'];
    const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = '\uFEFF' + [
      headers.join(','),
      ...rows.map((r, idx) =>
        [idx + 1, classify(r), r.displayName, r.handle, r.text, r.images, r.hasVideo, r.datetime, r.permalink]
          .map(esc).join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `x_bookmarks_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // 정리 후 해제
    let removedMsg = '';
    if (doRemove) {
      setStatus('🗑️ 북마크 해제 준비 중...');
      const set = new Set(rows.map((r) => r.permalink));
      const removed = await unbookmark(set);
      removedMsg = ` · ${removed}개 해제`;
    }

    stopKeepAwake();
    setStatus(`✅ 완료! ${rows.length}개 내보냄${removedMsg}`);
    lockUI(false);
  }

  const timer = setInterval(() => {
    if (document.body) { makePanel(); clearInterval(timer); }
  }, 800);
})();
